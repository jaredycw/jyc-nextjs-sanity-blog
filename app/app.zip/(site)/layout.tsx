import '../globals.css'
import '../styles/font.css'
import Link from "next/link"
import Image from "next/image"
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import Logo from '../component/Logo'
import Head from 'next/head'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'JYCW',
  description: 'Blog and Portfolio',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <header id="header" className="sticky-header">
          <div className="menu-bar-supper">
            <div className="menu-bar-wrapper">
              <div className="menu-bar flex items-center">
                <div className="logo"><Link href="/" ><Logo /></Link></div>
              </div>
            </div>
          
          </div>       
            
        </header>

        <main className="mt-20 pt-10">{children}</main>
        <footer id="site-footer" className="site-footer">

          <div className="container mx-auto">
                <div className="motto-wrapper">
                  <div className="motto-upper">Contact</div>
                  <div className="motto-capper">Chat</div>
                </div>
                <div className="footer-wrapper">
                    <div className="footer-msg">Copyright &copy; 2023. All Rights reserved.</div>
                    <div className="footer-msg">Designed and Developed by by Jared Yeung</div>
                    <div className="footer-msg">Powered by NextJS | Sanity CMS </div>
                </div>
 
            </div>

        </footer>
      </body>
    </html>
  )
}
