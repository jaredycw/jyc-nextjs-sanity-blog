
import Link from 'next/link';
import Image from 'next/image';
import Script from 'next/script';
import React from 'react';
import ExploreMoreBtn from '../component/exlporemorebtn';

import HeroSection from '../component/herosection';
import PostSection from '../component/postsection';
import HobbySection from '../component/hobbysection';
import MovieSection from '../component/moviesection';
import CraftSection from '../component/craftsection';
import WorkSection from '../component/worksection';
import ExperimentSection from '../component/expsection';
 
 
export default function Home() {
 

  return(
    <div>
    <div className="container mx-auto"> 
          <HeroSection/>
          <div id="jyz-post-list">
            <div className="section-title">
              <span className="section-name">Blog</span>
              <span className="section-desc">About Life</span>
            </div>
            <PostSection />
            <ExploreMoreBtn target="posts" />
          </div>

          <div id="section-hobby">
            <HobbySection />
          </div>

          <div id="section-watching">
            <MovieSection />
          </div>

          <div id="section-3d">
            <CraftSection />
          </div>
    </div>
       
          <div id="section-design">
            <div className="container mx-auto">
            <div className="section-title">
                
                <span className="section-name">Design</span>
              
                <span className="section-desc">About Works</span>
              
              </div>
            </div>
            <WorkSection />
            <div className="container mx-auto"><ExploreMoreBtn target="works"/> </div>
          </div>

          <div id="section-exp"> 
              <div className="container mx-auto">
                <div className="section-title">
                  
                  <span className="section-name">Experiment</span>
                
                  <span className="section-desc">About Stuffs</span>
                
                </div>
              </div>
              <ExperimentSection />
              <div className="container mx-auto"><ExploreMoreBtn target="experiments" /> </div>    
          
          
              
          </div>
  
        

    </div>

    
  );

}

 
