"use client"
 
import { InstagramEmbed } from 'react-social-media-embed';

export default function InstagramPost({url}) {
  return (
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <InstagramEmbed  url={url} width="100%" height={600} style={{
      maxWidth: 550
    }} />
    </div>
  );
}