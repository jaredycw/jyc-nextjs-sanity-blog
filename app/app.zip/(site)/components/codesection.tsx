"use client"

import {Prism as SyntaxHighlighter} from 'react-syntax-highlighter';
import { duotoneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

export default function CodeSection(props) {
    const codeString = '(num) => num + 1';
  return (
    <div className="bg-cyan-950 text-white">
        <div className="pl-10 pt-3">{props.filename}</div>
    <SyntaxHighlighter language={props.language} showLineNumbers={true} 
    wrapLongLines={true} style={duotoneDark}>       
        {props.code}
    </SyntaxHighlighter>
    </div>
  )
}