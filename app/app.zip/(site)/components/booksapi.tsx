"use client"
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Image from 'next/image';
import Link from 'next/link';
function BooksApiExample(props) {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const target = props.bookname;
        target.replace(/\s+/g, '');
        const link = "https://www.googleapis.com/books/v1/volumes?q=" + target;
        const response = await axios.get(link);
        setBooks(response.data.items);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);
  return (
    <>
    <h1>Results: {props.bookname}</h1>
    <div className="grid grid-cols-9 gap-7">
      
      {books.map((item, index) => (
        <div key={index}>
          <div>
            
            <p>
            <Link href={item.volumeInfo.canonicalVolumeLink} key={item.id} target="_blank">
            {item.volumeInfo.readingModes.image ? (
                  <img src={item.volumeInfo.imageLinks.thumbnail} alt={item.volumeInfo.title} width={300} height={300}/>
                ) : null}
              {item.volumeInfo.title}
            </Link>
            </p>
          </div>
        </div>
      ))}
    </div>
    </>
  )

}

export default BooksApiExample;