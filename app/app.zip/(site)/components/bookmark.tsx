'use client';
import React from "react";

const PrintButton = () => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <button onClick={handlePrint}>Print This Page</button>
  );
};

export default PrintButton;