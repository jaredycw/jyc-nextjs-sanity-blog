"use client"
import React, { useState, useEffect } from 'react';

const RandomItemDisplay = ({ items }) => {
  const [randomIndex, setRandomIndex] = useState(null);

  useEffect(() => {
    const maxIndex = items.length - 1;
    const index = Math.floor(Math.random() * (maxIndex + 1));
    setRandomIndex(index);
  }, [items]);

  return (
    <div>
      <h2>Random Item Display</h2>
      {randomIndex !== null && (
        <div>
          <p key={items._id}>{items[randomIndex].blackWording} : {items[randomIndex].greyWording} </p>
        </div>
      )}
    </div>
  );
};

export default RandomItemDisplay;
