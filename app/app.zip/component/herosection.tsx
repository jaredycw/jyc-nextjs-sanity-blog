
import Link from 'next/link';
import Image from 'next/image';

export default async function HeroSection() {
 
  return (
        <div>
                
 
        </div>
  );
}