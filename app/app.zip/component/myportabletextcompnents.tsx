import { PortableText } from '@portabletext/react';
import urlBuilder from '@sanity/image-url';
import {getImageDimensions} from '@sanity/asset-utils'
import Image from 'next/image';
 


export default async function myPortableTextComponents(props) {


// Barebones lazy-loaded image component
const SampleImageComponent = ({value, isInline}) => {
  const {width, height} = getImageDimensions(value)
 
  return (
    
    <div class="my-10">
    <Image
      src={urlBuilder()
          .image(value)
          .projectId('mrzc8peh')
          .dataset('production')
          .auto('format')
          .width(isInline ? 100 : 800)
          .fit('max')
          .url()}
          width={1920}
          height={1080}
          alt={value.alt || ' '}
          loading="lazy"
          blurDataURL={value.lqip}
          placeholder="blur"
          style={{
              // Display alongside text if image appears inside a block text span
              display: isInline ? 'inline-block' : 'block',
              // Avoid jumping around with aspect-ratio CSS property
              aspectRatio: width / height,
            }
          }
    />
    <p className="text-center text-gray-400 my-5 image-caption">{value.caption}</p>
    </div>
    
  )
}


const components = {
  types: {
    image: SampleImageComponent,
    // Any other custom types you have in your content
    // Examples: mapLocation, contactForm, code, featuredProjects, latestNews, etc.
  }
}

  return (
  <div> testing12345</div>
    
  );
}
