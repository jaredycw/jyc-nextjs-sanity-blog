export default function Menu() {
    return (
        <div id="section-3d">
            Stay Tuned!ThreeJS
        </div>        
    )
  }