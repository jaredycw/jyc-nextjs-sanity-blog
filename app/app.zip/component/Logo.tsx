import Image from "next/image"
import logo from "../images/svg/logo.svg"

export default function Logo() {
  return (
    <Image
    priority
    src={logo}
    width={200}
    height={300}
    alt="Logo"
  />
  );
}