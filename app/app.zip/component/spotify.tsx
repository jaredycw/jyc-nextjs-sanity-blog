 "use client"
 import React from "react";
 import useSWR from 'swr';
import { SpotifyData } from "@/spotify";
 

 export default function Spotify(){
  const { data } = useSWR<SpotifyData>('http://localhost:3000/api/spotify"');
  return data?.isPlaying ? (
    <>

      {data.title}
      {data.album}
      {data.albumImageUrl}
      {data.artist}
      {data.songUrl}
      <div>testing 123458888ssss</div>
    </>
  ): (
    <>
    {data}
    {data?.isPlaying}
    {data?.title}
 <div>testing 123458888sdassss</div>
    </ >
  );
 }
